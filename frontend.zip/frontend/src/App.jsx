import { useState } from "react";
import "./App.css";

function App() {
  const [formData, setFormData] = useState({
    age: "",
    gender: "",
    category: "",
    annual_income: "",
    business_type: "",
    required_amount: "",
    state: "",
    district: "",
  });

  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedScheme, setSelectedScheme] = useState(null);

  // AI / RAG Search
  const [aiQuery, setAiQuery] = useState("");
  const [aiResults, setAiResults] = useState([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Normal scheme matching
  const findSchemes = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");
    setMatches([]);
    setSelectedScheme(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/match", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          age: Number(formData.age),
          annual_income: Number(formData.annual_income),
          required_amount: Number(formData.required_amount),
        }),
      });

      if (!response.ok) {
        throw new Error("Unable to find schemes");
      }

      const data = await response.json();
      setMatches(data.matches);
    } catch (err) {
      setError(
        "Backend se connection nahi ho pa raha. Check karo ki FastAPI server chal raha hai."
      );
    } finally {
      setLoading(false);
    }
  };

  // AI / RAG semantic search
  const handleAISearch = async () => {
    if (!aiQuery.trim()) {
      setAiError("Please enter your business requirement.");
      return;
    }

    setAiLoading(true);
    setAiError("");
    setAiResults([]);

    try {
      const response = await fetch("http://127.0.0.1:8000/ai-search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: aiQuery,
        }),
      });

      if (!response.ok) {
        throw new Error("AI search failed");
      }

      const data = await response.json();

      if (data.results) {
        setAiResults(data.results);
      } else {
        setAiError("AI se koi result nahi mila.");
      }
    } catch (err) {
      setAiError(
        "AI Search connect nahi ho pa raha. Check karo ki FastAPI server chal raha hai."
      );
    } finally {
      setAiLoading(false);
    }
  };

  const getMatchLevel = (score) => {
    if (score >= 80) return "Excellent Match";
    if (score >= 60) return "Good Match";
    if (score >= 40) return "Moderate Match";
    return "Low Match";
  };

  return (
    <div className="app">
      <header className="header">
        <div>
          <h1>AI Scheme Matcher</h1>
          <p>
            Find government schemes that match your business profile
          </p>
        </div>
      </header>

      <main className="container">

        {/* Hero */}
        <section className="hero">
          <h2>Find the Right Government Scheme</h2>
          <p>
            Apni basic information enter karo aur apne liye suitable
            government schemes discover karo.
          </p>
        </section>

        {/* AI / RAG SEARCH */}
        <section className="card ai-search-section">
          <h2>🤖 Ask AI About Government Schemes</h2>

          <p>
            Apni business requirement normal language mein likho aur AI
            relevant government schemes find karega.
          </p>

          <div className="ai-search-box">
            <input
              type="text"
              value={aiQuery}
              onChange={(e) => setAiQuery(e.target.value)}
              placeholder="Example: Mujhe women entrepreneur ke liye business loan chahiye..."
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleAISearch();
                }
              }}
            />

            <button
              type="button"
              onClick={handleAISearch}
              disabled={aiLoading}
              className="match-button"
            >
              {aiLoading ? "AI Searching..." : "Ask AI"}
            </button>
          </div>

          {aiError && <div className="error">{aiError}</div>}
        </section>

        {/* AI RESULTS */}
        {aiResults.length > 0 && (
          <section className="results ai-results">
            <h2>🤖 AI Recommended Schemes</h2>

            {aiResults.map((result, index) => (
              <div className="scheme-card" key={index}>

                <div className="scheme-header">
                  <div>
                    <h3>{result.scheme_name}</h3>
                    <span>{result.benefit_type}</span>
                  </div>

                  <div className="score">
                    {result.semantic_score}%
                    <small>AI Relevance</small>
                  </div>
                </div>

                <p className="description">
                  {result.description}
                </p>

                <div className="section">
                  <h4>Required Documents</h4>

                  <ul>
                    {result.documents.map((document, i) => (
                      <li key={i}>• {document}</li>
                    ))}
                  </ul>
                </div>

                <a
                  href={result.official_link}
                  target="_blank"
                  rel="noreferrer"
                  className="official-button"
                >
                  Official Website
                </a>

              </div>
            ))}
          </section>
        )}

        {/* ENTREPRENEUR PROFILE */}
        <section className="card">
          <h2>Entrepreneur Profile</h2>

          <form onSubmit={findSchemes}>
            <div className="form-grid">

              <div className="field">
                <label>Age</label>
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleChange}
                  placeholder="Enter your age"
                  required
                />
              </div>

              <div className="field">
                <label>Gender</label>

                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="field">
                <label>Social Category</label>

                <select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select category</option>
                  <option value="SC">SC</option>
                  <option value="ST">ST</option>
                  <option value="OBC">OBC</option>
                  <option value="General">General</option>
                  <option value="Women">Women</option>
                </select>
              </div>

              <div className="field">
                <label>Annual Income</label>

                <input
                  type="number"
                  name="annual_income"
                  value={formData.annual_income}
                  onChange={handleChange}
                  placeholder="Enter annual income"
                  required
                />
              </div>

              <div className="field">
                <label>Business Type</label>

                <select
                  name="business_type"
                  value={formData.business_type}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select business type</option>
                  <option value="Manufacturing">Manufacturing</option>
                  <option value="Trading">Trading</option>
                  <option value="Services">Services</option>
                  <option value="Traditional Artisan">
                    Traditional Artisan
                  </option>
                  <option value="Craft">Craft</option>
                </select>
              </div>

              <div className="field">
                <label>Required Loan Amount</label>

                <input
                  type="number"
                  name="required_amount"
                  value={formData.required_amount}
                  onChange={handleChange}
                  placeholder="Enter required amount"
                  required
                />
              </div>

              <div className="field">
                <label>State</label>

                <input
                  type="text"
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                  placeholder="Enter your state"
                  required
                />
              </div>

              <div className="field">
                <label>District</label>

                <input
                  type="text"
                  name="district"
                  value={formData.district}
                  onChange={handleChange}
                  placeholder="Enter your district"
                  required
                />
              </div>

            </div>

            <button type="submit" className="match-button">
              {loading ? "Finding Schemes..." : "Find Best Schemes"}
            </button>
          </form>
        </section>

        {/* ERROR */}
        {error && <div className="error">{error}</div>}

        {/* NORMAL MATCH RESULTS */}
        {matches.length > 0 && (
          <section className="results">
            <h2>Recommended Schemes</h2>

            {matches.map((scheme, index) => (
              <div className="scheme-card" key={index}>

                <div className="scheme-header">
                  <div>
                    <h3>{scheme.scheme_name}</h3>
                    <span>{scheme.benefit_type}</span>
                  </div>

                  <div className="score">
                    {scheme.match_score}%
                    <small>Match</small>
                  </div>
                </div>

                <div className="match-score-section">
                  <div className="match-score-header">
                    <strong>Match Score</strong>
                    <span>
                      {getMatchLevel(scheme.match_score)}
                    </span>
                  </div>

                  <div className="progress-background">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${scheme.match_score}%`,
                      }}
                    ></div>
                  </div>
                </div>

                <p className="description">
                  {scheme.description}
                </p>

                {scheme.reasons.length > 0 && (
                  <div className="section">
                    <h4>Why this scheme matches</h4>

                    <ul>
                      {scheme.reasons.map((reason, i) => (
                        <li key={i}>✓ {reason}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {scheme.missing.length > 0 && (
                  <div className="section">
                    <h4>Things to check</h4>

                    <ul>
                      {scheme.missing.map((item, i) => (
                        <li key={i}>• {item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  className="details-button"
                  onClick={() => setSelectedScheme(scheme)}
                >
                  View Scheme Details
                </button>

                <a
                  href={scheme.official_link}
                  target="_blank"
                  rel="noreferrer"
                  className="official-button"
                >
                  Official Website
                </a>

              </div>
            ))}
          </section>
        )}
      </main>

      {/* SCHEME DETAILS MODAL */}
      {selectedScheme && (
        <div
          className="modal-overlay"
          onClick={() => setSelectedScheme(null)}
        >
          <div
            className="modal"
            onClick={(e) => e.stopPropagation()}
          >

            <button
              className="close-button"
              onClick={() => setSelectedScheme(null)}
            >
              ×
            </button>

            <h2>{selectedScheme.scheme_name}</h2>

            <span className="modal-badge">
              {selectedScheme.benefit_type}
            </span>

            <div className="modal-score">
              <strong>{selectedScheme.match_score}%</strong>
              <span>
                {getMatchLevel(selectedScheme.match_score)}
              </span>
            </div>

            <div className="modal-section">
              <h3>About this scheme</h3>
              <p>{selectedScheme.description}</p>
            </div>

            <div className="modal-section">
              <h3>Why you matched</h3>

              {selectedScheme.reasons.length > 0 ? (
                <ul>
                  {selectedScheme.reasons.map((reason, i) => (
                    <li key={i}>✓ {reason}</li>
                  ))}
                </ul>
              ) : (
                <p>No matching factors found.</p>
              )}
            </div>

            {selectedScheme.missing.length > 0 && (
              <div className="modal-section">
                <h3>Things to check</h3>

                <ul>
                  {selectedScheme.missing.map((item, i) => (
                    <li key={i}>• {item}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="modal-section">
              <h3>Required Documents</h3>

              <div className="documents">
                {selectedScheme.documents.map((document, i) => (
                  <span key={i}>{document}</span>
                ))}
              </div>
            </div>

            <a
              href={selectedScheme.official_link}
              target="_blank"
              rel="noreferrer"
              className="modal-official-button"
            >
              Visit Official Website →
            </a>

          </div>
        </div>
      )}
    </div>
  );
}

export default App;